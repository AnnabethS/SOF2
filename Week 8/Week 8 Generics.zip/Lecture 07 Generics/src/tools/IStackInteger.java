package tools;

public interface IStackInteger {

    boolean isEmpty();

    boolean push(Integer value);

    Integer peek();

    Integer pop();
}